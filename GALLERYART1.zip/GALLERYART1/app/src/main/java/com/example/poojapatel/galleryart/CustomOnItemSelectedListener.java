package com.example.poojapatel.galleryart;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;

import static androidx.core.content.ContextCompat.startActivity;

class CustomOnItemSelectedListener implements android.widget.AdapterView.OnItemSelectedListener {


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
